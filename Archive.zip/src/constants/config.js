export default {
  API_HOST: 'api-g.weedmaps.com',
  SIZES: {
    sm: '320px',
    md: '768px',
    lg: '1024px',
    xl: '1440px'
  },
  ROUTES: []
};
