export const REQUEST = 'REQUESTING';
export const RECEIVE = 'RECEIVING';
export const LOCATE = 'LOCATING';
export const ERROR = 'ERROR';
